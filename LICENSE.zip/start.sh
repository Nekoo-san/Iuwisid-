#!/bin/bash

while :
do
    node bot.js

done