module.exports = {
    config: {
        name: "resume",
    },
    run: async (client, message, args) => {
        if (client.global.paused) {
            if (client.global.captchadetected) {
                client.global.captchadetected = false;
            }
            client.global.paused = false;
            client.rpc("update");
            await message.delete();
            await message.channel.send({ content: "Resuming :)" });
        } else {
            await message.delete();
            await message.channel.send({
                content: "Bot is already working!!!",
            });
        }
    },
};
